<?php
/**
 *
 * Simon Brown <uptoeleven@gmail.com>
 */

namespace AppBundle\Service;

use AppBundle\Entity\Boat;
use Symfony\Component\DependencyInjection\Container;

/**
 * Class CalculateRequirement
 * @package AppBundle\Service
 */
class CalculateRequirement
{
    /**
     * @var ContainerInterface|Container
     */
    protected $container;

    /**
     * CalculateRequirement constructor.
     * @param Container $container
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    public function generateSpeedPowerCurve(Boat $data)
    {
        $maxSpeed = 30;
        // plane speed
        $nominalHullSpeed = $this->calculateHullSpeed($data);
        $speedPowerCurve = [];
        for ($i=0; $i<=$nominalHullSpeed; $i++) {
            $speedPowerCurve[] = [
                'speed' => $i,
                'power' => round($this->calculateHorsePower($data, $i), 2)
            ];
        }
        $speedPowerCurve[] = [
            'speed' => round($nominalHullSpeed, 2) . ' (Nominal Hull Speed)',
            'power' => round($this->calculateHorsePower($data, $nominalHullSpeed), 2)
        ];
        for ($i=(intval($nominalHullSpeed) + 1); $i<=$maxSpeed; $i++) {
            $speedPowerCurve[] = [
                'speed' => $i,
                'power' => round($this->calculateHorsePower($data, $i), 2)
            ];
        }
        return $speedPowerCurve;
    }

    /**
     * Calculate HP
     *
     * @param Boat $data
     * @param $kt
     * @return float|int
     */
    public function calculateHorsePower(Boat $data, $kt)
    {
        return ($this->calculateDisplacementInLBS($data) / 1000) *
            pow($kt / ($this->calculateWymanCoefficient($data) * sqrt($this->convertToFeet($data))), 3);
    }

    /**
     * Calculate SL Ratio
     *
     * @param Boat $data
     * @return float|mixed
     */
    public function calculateSlRatio(Boat $data)
    {
        return ($data->getButtockAngle() * -0.2) + 2.9;
    }

    /**
     * Calculate Hull Speed
     *
     * @param Boat $data
     * @return float|mixed
     */
    public function calculateHullSpeed(Boat $data)
    {
        return $this->calculateSlRatio($data) * (sqrt($this->convertToFeet($data)));

    }

    /**
     * Convert to Feet
     *
     * @param Boat $data
     * @return mixed
     */
    public function convertToFeet(Boat $data)
    {

        switch ($data->getLengthUnit()) {
            case 'inch' :
                return $data->getHullLength() * 0.0833333;
                break;
            case 'metre' :
                return $data->getHullLength() * 3.28084;
                break;
            default:
                break;
        }
        return $data->getHullLength();
    }

    /**
     * Calculate Wyman Coefficient
     *
     * @param Boat $boat
     * @return float|mixed
     */
     public function calculateWymanCoefficient(Boat $boat)
    {
        return 0.8 + (0.17 * $this->calculateSlRatio($boat));
    }

    /**
     * Get Displacement
     *
     * @param Boat $data
     * @return float|mixed
     */
    private function calculateDisplacementInLBS(Boat $data)
    {
        if ($data->getDispUnit() != 'lbs') {
            switch ($data->getDispUnit()) {
                case 'kilogram' :
                    return $data->getDisplacement() * 2.20462;
                    break;
                case 'gram' :
                    return $data->getDisplacement() * 0.00220462;
                    break;
                default:
                    break;
            }
        }
        return $data->getDisplacement();
    }
}